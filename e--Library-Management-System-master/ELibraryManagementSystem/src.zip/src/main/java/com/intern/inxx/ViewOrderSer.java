package com.intern.inxx;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet("/viewOrder")
public class ViewOrderSer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public ViewOrderSer() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		String bookid = request.getParameter("inputBookid3");
//		String title = request.getParameter("inputTitle3");
//		String author = request.getParameter("inputAuthor3");

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibraryManagementSystem",
					"root", "W7301@jqir#");
			Statement statement = connection.createStatement();
			String query = "SELECT * FROM book WHERE bood_id = " + bookid;
			ResultSet resultSet = statement.executeQuery(query);

			if (resultSet.next()) {
				HttpSession httpSession = request.getSession();
				httpSession.setAttribute("message", "hi");
				response.sendRedirect("ViewOrder.jsp");
			} else {
				HttpSession httpSession = request.getSession();
				httpSession.setAttribute("message1", null);
				response.sendRedirect("ViewOrder.jsp");
			}
			resultSet.close();
			statement.close();
			connection.close();
		} catch (SQLException e) {
			HttpSession httpSession = request.getSession();
			httpSession.setAttribute("message1", "hi");
			response.sendRedirect("ViewOrder.jsp");
			e.printStackTrace();
		}
	}

}
